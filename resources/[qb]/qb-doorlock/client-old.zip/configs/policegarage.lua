Config.DoorList['bollards'] = {
    authorizedJobs = { ['police'] = 0 },
    pickable = false,
    distance = 10,
    doors = {
        {objName = -1868050792, objYaw = 269.99661254883, objCoords = vec3(410.025787, -1024.225952, 29.220221)},
        {objName = -1635161509, objYaw = 270.0, objCoords = vec3(410.025787, -1024.219971, 29.220200)}
    },
    doorRate = 1.0,
    audioRemote = true,
    doorType = 'garage',
    locked = true,
    audioLock = {['file'] = 'metal-locker.ogg', ['volume'] = 0.6},
    audioUnlock = {['file'] = 'metallic-creak.ogg', ['volume'] = 0.7},
    autoLock = 1000,
}